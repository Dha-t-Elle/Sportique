$('.products__sort-popularity > .item').click(function() {
    $('.products__list .item').addClass('all')
});
$('.products__sort-popularity > .all').click(function() {
    $('.products__list .item').removeClass('all')
});
$('.open__item-hidden').click(function() {
    $('.open__item-hidden-text').toggleClass(function() {
        if ($(this).is(':visible')) {
            $(".products__categories-similar").ready(function() {
                max = 8;
                i = 1;
                $(".products__categories-similar .item").each(function() {
                    i += 3;
                    if (i > max) {
                        $(this).addClass("foo");
                    }
                });
            });
            $('.open__item-hidden-text').html('Полный текст222').click(function() {
                $(".products__categories-similar .item").removeClass('foo');

            });
        } else {
            $('.open__item-hidden-text').html('Полный текст111');
            $(".products__categories-similar .item").removeClass('foo');
        }
    });
});